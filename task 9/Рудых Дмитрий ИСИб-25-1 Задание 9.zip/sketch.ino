const int RED_LED = 9;
const int GREEN_LED = 5;
const int LDR_PIN = A0;

const int THRESHOLD = 512;
const unsigned long OPEN_TIME = 3000;

void setup() {
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  
  Serial.begin(9600);
  
  digitalWrite(RED_LED, HIGH);
  digitalWrite(GREEN_LED, LOW);
  Serial.println("System started. Doors are CLOSED.");
}

void loop() {
  int ldrValue = analogRead(LDR_PIN);
  
  if (ldrValue > THRESHOLD) {
    Serial.println("Event: Person detected. Opening doors...");
    
    digitalWrite(RED_LED, LOW);
    digitalWrite(GREEN_LED, HIGH);
    
    delay(OPEN_TIME);
    
    int currentLdrValue = analogRead(LDR_PIN);
    
    if (currentLdrValue > THRESHOLD) {
      Serial.println("Event: Person is still there. Doors stay OPEN.");
    } else {
      Serial.println("Event: Area clear. Closing doors...");
      digitalWrite(GREEN_LED, LOW);
      digitalWrite(RED_LED, HIGH);
    }
  }
  
  delay(100);
}