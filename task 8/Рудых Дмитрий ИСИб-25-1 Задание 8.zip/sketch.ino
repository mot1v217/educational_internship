#include <Adafruit_NeoPixel.h>

#define PIN 3           // Сигнальный пин (DIN)
#define NUMPIXELS 64    // 64 лампочки для матрицы 8x8

Adafruit_NeoPixel pixels(NUMPIXELS, PIN, NEO_GRB + NEO_KHZ800);

void setup() {
  pixels.begin();
  pixels.setBrightness(40); // Яркость (0-255)
  pixels.show(); 
}

void loop() {
  // АНИМАЦИЯ: Бегущий квадрат. 
  // Мы будем зажигать одну точку за другой и сдвигать её.
  
  // Проходим по всей длине (64 пикселя)
  for(int i = 0; i < NUMPIXELS; i++) {
    
    // 1. Сначала очищаем ВСЁ поле
    pixels.clear(); 
    
    // 2. Зажигаем текущую точку зеленым цветом
    pixels.setPixelColor(i, pixels.Color(0, 255, 0)); 
    
    // 3. Обновляем картинку на матрице
    pixels.show();
    
    // 4. Ждем (скорость бега). Чем меньше число, тем быстрее.
    delay(50); 
  }

  // Теперь то же самое, но в обратную сторону (чтобы было красиво)
  for(int i = NUMPIXELS - 1; i >= 0; i--) {
    pixels.clear();
    pixels.setPixelColor(i, pixels.Color(255, 0, 0)); // Красный цвет назад
    pixels.show();
    delay(50); 
  }
}