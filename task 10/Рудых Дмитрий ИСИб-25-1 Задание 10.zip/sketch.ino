#include <Servo.h>

Servo myServo;
const int SERVO_PIN = 3;
int currentAngle = 90;

void setup() {
  Serial.begin(9600);
  myServo.attach(SERVO_PIN);
  myServo.write(currentAngle);
  Serial.println("Servo system ready. Enter angle (0-180):");
}

void loop() {
  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');
    input.trim();
    
    if (input.length() == 0) return;
    
    bool isValid = true;
    for (byte i = 0; i < input.length(); i++) {
      if (!isDigit(input[i])) {
        isValid = false;
        break;
      }
    }
    
    if (!isValid) {
      Serial.println("Error: Input must be a number.");
      return;
    }
    
    int targetAngle = input.toInt();
    
    if (targetAngle < 0 || targetAngle > 180) {
      Serial.println("Error: Angle must be between 0 and 180.");
      return;
    }
    
    if (targetAngle != currentAngle) {
      int step = (targetAngle > currentAngle) ? 1 : -1;
      
      while (currentAngle != targetAngle) {
        currentAngle += step;
        myServo.write(currentAngle);
        delay(15);
      }
      
      Serial.print("Servo moved to: ");
      Serial.println(currentAngle);
    } else {
      Serial.println("Servo is already at this angle.");
    }
  }
}